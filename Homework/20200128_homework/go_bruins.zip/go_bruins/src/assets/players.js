const pbergeron = {
    name: "Patrice Bergeron",
    number: 37,
    position: "Center",
    height: 73,
    weight: 195,
    age: 34,
    url:"https://www.nhl.com/player/patrice-bergeron-8470638"
}

const abjork = {
    name: "Anders Bjork",
    number: 10,
    position: "Left Wing",
    height: 72,
    weight: 190,
    age: 23,
    url:"https://www.nhl.com/player/anders-bjork-8478075"
}

const ablidh = {
    name: "Anton Blidh",
    number: 10,
    position: "Left Wing",
    height: 72,
    weight: 201,
    age: 24,
    url:"https://www.nhl.com/player/anton-blidh-8477320"
}

const ccoyle = {
    name: "Charlie Coyle",
    number: 13,
    position: "Center",
    height: 75,
    weight: 220,
    age: 27,
    url:"https://www.nhl.com/player/charlie-coyle-8475745"
}

const jdebrusk = {
    name: "Jake DeBrusk",
    number: 13,
    position: "Left Wing",
    height: 72,
    weight: 188,
    age: 23,
    url:"https://www.nhl.com/player/jake-debrusk-8478498"
}

const players = [pbergeron, abjork, ablidh, ccoyle, jdebrusk];

export default players;